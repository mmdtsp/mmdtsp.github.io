import Suggestrap from 'js/suggestrap'

export default Suggestrap

export { Suggestrap }